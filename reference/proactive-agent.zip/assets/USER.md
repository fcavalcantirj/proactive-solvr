# USER.md - About My Human

> Fill this in with your human's context. The more you know, the better you can serve.

- **Name:** [Name]
- **What to call them:** [Preferred name]
- **Timezone:** [e.g., America/Los_Angeles]
- **Notes:** [Brief description of their style/preferences]

---

## Life Goals & Context

### Primary Goal
[What are they working toward? What does success look like?]

### Current Projects
[What are they actively working on?]

### Key Relationships
[Who matters to them? Collaborators, family, key people?]

### Preferences
- **Communication style:** [Direct? Detailed? Brief?]
- **Work style:** [Morning person? Deep work blocks? Async?]
- **Pet peeves:** [What to avoid?]

---

## What Winning Looks Like

[Describe their ideal outcome - not just goals, but what life looks/feels like when they've succeeded]

---

*Update this as you learn more. The better you know them, the more value you create.*
